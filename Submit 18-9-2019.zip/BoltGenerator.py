#Author-Masoun Mardini
#Description-Bolt Generator with insert option
"""
Created on Tue Sep 11 11:09:31 2018

@author: Masoun Mardini
"""

from . import Bolt_Generator as BG

def run(context):
    BG.run(context)

def stop(context):
    BG.stop(context)


          
